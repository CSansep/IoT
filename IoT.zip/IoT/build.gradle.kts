// ============================================================
// Build script raíz del proyecto
// TI3042 - Sistema de Control de Accesos y Monitoreo Perimetral
// ============================================================

plugins {
    id("com.android.application") version "8.2.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.22" apply false
    id("com.google.devtools.ksp") version "1.9.22-1.0.17" apply false
}

