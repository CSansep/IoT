package com.ti3042.iotaccess.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Entidad de usuario para la base de datos Room.
 *
 * Seguridad ISO 27001 (A.9.4 - Control de acceso a sistemas y aplicaciones):
 * - La contraseña NUNCA se almacena en texto plano.
 * - Se guarda el hash SHA-256 con salt aleatorio en formato "salt:hash".
 * - Control estricto de intentos fallidos (bloqueo automático tras 3 intentos).
 * - Asignación de rol de seguridad (ADMIN / OPERADOR).
 *
 * @property id Identificador auto-generado.
 * @property username Nombre de usuario único.
 * @property passwordHash Hash SHA-256 con salt (formato "salt:hash").
 * @property role Rol del usuario: "ADMIN" u "OPERADOR".
 * @property failedAttempts Contador de intentos fallidos consecutivos de login.
 * @property isLocked Indica si la cuenta se encuentra bloqueada por exceder los 3 intentos.
 * @property createdAt Marca temporal de creación (epoch millis).
 */
@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val username: String,
    val passwordHash: String, // Formato: "saltHex:hashHex" (SHA-256 + Salt)
    val role: String = "OPERADOR", // "ADMIN" o "OPERADOR"
    val failedAttempts: Int = 0,
    val isLocked: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
