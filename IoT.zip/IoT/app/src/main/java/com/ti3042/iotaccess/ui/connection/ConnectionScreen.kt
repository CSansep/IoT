@file:OptIn(ExperimentalMaterial3Api::class)

package com.ti3042.iotaccess.ui.connection

import android.annotation.SuppressLint
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LinkOff
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ti3042.iotaccess.network.ConnectionManager

/**
 * Pantalla de configuración de conexión entre dispositivos.
 *
 * Permite al usuario:
 * - Elegir Wi-Fi TCP o Bluetooth Classic RFCOMM.
 * - Configurar IP/Puerto (Wi-Fi) o seleccionar dispositivo emparejado (BT).
 * - Ingresar la clave de cifrado AES-256 compartida.
 * - Iniciar/detener la conexión.
 *
 * @param viewModel ViewModel de conexión.
 * @param role Rol seleccionado ("panel" o "nodo").
 * @param onConnected Callback cuando la conexión se establece.
 */
@SuppressLint("MissingPermission")
@Composable
fun ConnectionScreen(
    viewModel: ConnectionViewModel,
    role: String,
    onConnected: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    // Navegar cuando se conecte exitosamente
    LaunchedEffect(uiState.isConnected) {
        if (uiState.isConnected) {
            onConnected()
        }
    }

    val isWaiting = uiState.connectionState == ConnectionManager.ConnectionState.LISTENING ||
            uiState.connectionState == ConnectionManager.ConnectionState.CONNECTING

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        if (role == "panel") "Conexión — Panel de Control"
                        else "Conexión — Nodo Perimetral"
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // ========== TIPO DE CONEXIÓN ==========
            Text(
                text = "Tipo de Conexión",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))

            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = uiState.connectionType == "wifi",
                    onClick = { viewModel.setConnectionType("wifi") },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                    icon = { Icon(Icons.Filled.Wifi, contentDescription = null, Modifier.size(18.dp)) }
                ) {
                    Text("Wi-Fi TCP")
                }
                SegmentedButton(
                    selected = uiState.connectionType == "bluetooth",
                    onClick = { viewModel.setConnectionType("bluetooth") },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                    icon = { Icon(Icons.Filled.Bluetooth, contentDescription = null, Modifier.size(18.dp)) }
                ) {
                    Text("Bluetooth")
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // ========== MODO: SERVIDOR / CLIENTE ==========
            Text(
                text = "Modo de Conexión",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { viewModel.setIsServer(true) }
                ) {
                    RadioButton(
                        selected = uiState.isServer,
                        onClick = { viewModel.setIsServer(true) }
                    )
                    Text("Esperar conexión (Servidor)", style = MaterialTheme.typography.bodyMedium)
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { viewModel.setIsServer(false) }
                ) {
                    RadioButton(
                        selected = !uiState.isServer,
                        onClick = { viewModel.setIsServer(false) }
                    )
                    Text("Conectar (Cliente)", style = MaterialTheme.typography.bodyMedium)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // ========== CONFIGURACIÓN Wi-Fi ==========
            AnimatedVisibility(visible = uiState.connectionType == "wifi") {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // IP del servidor (solo visible en modo cliente)
                    AnimatedVisibility(visible = !uiState.isServer) {
                        OutlinedTextField(
                            value = uiState.ipAddress,
                            onValueChange = { viewModel.setIpAddress(it) },
                            label = { Text("Dirección IP del servidor") },
                            placeholder = { Text("Ej: 192.168.1.100") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                        )
                    }

                    OutlinedTextField(
                        value = uiState.port,
                        onValueChange = { viewModel.setPort(it) },
                        label = { Text("Puerto TCP") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                }
            }

            // ========== CONFIGURACIÓN BLUETOOTH ==========
            AnimatedVisibility(visible = uiState.connectionType == "bluetooth" && !uiState.isServer) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Dispositivos Emparejados",
                        style = MaterialTheme.typography.titleMedium
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    if (uiState.pairedDevices.isEmpty()) {
                        Text(
                            text = "No hay dispositivos emparejados.\nEmpareje un dispositivo desde Configuración de Bluetooth.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        uiState.pairedDevices.forEach { device ->
                            val deviceName = device.name ?: device.address
                            val isSelected = uiState.selectedBtDevice?.address == device.address

                            FilterChip(
                                selected = isSelected,
                                onClick = { viewModel.selectBluetoothDevice(device) },
                                label = { Text(deviceName) },
                                leadingIcon = if (isSelected) {
                                    { Icon(Icons.Filled.Check, contentDescription = null, Modifier.size(18.dp)) }
                                } else null,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                }
            }

            // ========== CLAVE DE CIFRADO AES-256 ==========
            OutlinedTextField(
                value = uiState.encryptionKey,
                onValueChange = { viewModel.setEncryptionKey(it) },
                label = { Text("Clave de cifrado AES-256 (compartida)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                supportingText = {
                    Text("Ambos dispositivos deben usar la misma clave (ISO 27400)")
                }
            )

            Spacer(modifier = Modifier.height(20.dp))

            // ========== MENSAJE DE ERROR ==========
            AnimatedVisibility(visible = uiState.errorMessage != null) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                ) {
                    Text(
                        text = uiState.errorMessage ?: "",
                        modifier = Modifier.padding(16.dp),
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            // ========== ESTADO ACTUAL ==========
            AnimatedVisibility(visible = isWaiting) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = when (uiState.connectionState) {
                            ConnectionManager.ConnectionState.LISTENING -> "Esperando conexión entrante..."
                            ConnectionManager.ConnectionState.CONNECTING -> "Conectando..."
                            else -> ""
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // ========== BOTONES DE ACCIÓN ==========
            if (!isWaiting && !uiState.isConnected) {
                Button(
                    onClick = { viewModel.connect() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                ) {
                    Icon(Icons.Filled.Link, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        if (uiState.isServer) "Iniciar y Esperar Conexión"
                        else "Conectar"
                    )
                }
            } else if (isWaiting) {
                OutlinedButton(
                    onClick = { viewModel.disconnect() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                ) {
                    Icon(Icons.Filled.LinkOff, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Cancelar")
                }
            }
        }
    }
}

