package com.ti3042.iotaccess.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Entidad para el registro de eventos del sistema (log de trazabilidad).
 *
 * ISO 27001 (A.12.4 - Registro y monitoreo):
 * Cada evento queda registrado en SQLite para auditoría y trazabilidad completa.
 *
 * @property id Identificador auto-generado.
 * @property timestamp Marca temporal del evento (epoch millis).
 * @property eventType Tipo: TELEMETRY, COMMAND, ALERT, CONNECTION, AUTH.
 * @property description Descripción legible del evento.
 * @property deviceRole Rol del dispositivo: PANEL o NODO.
 */
@Entity(tableName = "event_logs")
data class EventLog(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val eventType: String,
    val description: String,
    val deviceRole: String
)

