@file:OptIn(ExperimentalMaterial3Api::class)

package com.ti3042.iotaccess.ui.node

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoMode
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.PrecisionManufacturing
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ti3042.iotaccess.data.entity.EventLog
import com.ti3042.iotaccess.network.ConnectionManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Pantalla de Nodo Perimetral (Simulador IoT).
 *
 * Permite simular el hardware perimetral de un nodo IoT:
 * - Simulación manual o automática del Sensor Ultrasónico HC-SR04 (slider de distancia).
 * - Simulación de detección del Sensor de Movimiento PIR HC-SR501.
 * - Visualización en vivo del estado de los actuadores controlados desde el Panel:
 *   - Servomotor SG90 (ángulo de pestillo).
 *   - Buzzer de advertencia sonora.
 *   - LEDs de señalización de alerta.
 *   - Estado de Armado / Desarmado.
 * - Historial de eventos locales en SQLite para trazabilidad.
 */
@Composable
fun NodeScreen(
    viewModel: NodeViewModel,
    onDisconnect: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val events by viewModel.recentEvents.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.PrecisionManufacturing,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("Nodo Perimetral (Simulador IoT)", style = MaterialTheme.typography.titleMedium)
                            Text(
                                text = if (uiState.connectionState == ConnectionManager.ConnectionState.CONNECTED)
                                    "Conectado • Transmitiendo Telemetría"
                                else "Esperando conexión",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (uiState.connectionState == ConnectionManager.ConnectionState.CONNECTED)
                                    MaterialTheme.colorScheme.secondary
                                else MaterialTheme.colorScheme.error
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = {
                        viewModel.disconnect()
                        onDisconnect()
                    }) {
                        Icon(
                            Icons.Filled.PowerSettingsNew,
                            contentDescription = "Desconectar",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // ==========================================
            // SECCIÓN 1: ESTADO RECIBIDO DE ACTUADORES
            // ==========================================
            item {
                Text(
                    text = "Estado Actual de Actuadores (Control remoto)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        // Estado de Armado
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    if (uiState.isSystemArmed) Icons.Filled.Lock else Icons.Filled.LockOpen,
                                    contentDescription = null,
                                    tint = if (uiState.isSystemArmed) MaterialTheme.colorScheme.primary else Color.Gray
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Estado del Sistema:", style = MaterialTheme.typography.bodyMedium)
                            }
                            Text(
                                text = if (uiState.isSystemArmed) "ARMADO" else "DESARMADO",
                                fontWeight = FontWeight.Bold,
                                color = if (uiState.isSystemArmed) MaterialTheme.colorScheme.primary else Color.Gray
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Servomotor SG90
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Servomotor SG90 (Pestillo):", style = MaterialTheme.typography.bodyMedium)
                            Text(
                                text = "${uiState.servoAngle}° (${if (uiState.servoAngle > 90) "Abierto" else "Bloqueado"})",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Buzzer y LEDs
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Filled.NotificationsActive,
                                    contentDescription = null,
                                    tint = if (uiState.isBuzzerActive) Color.Red else Color.Gray
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (uiState.isBuzzerActive) "Buzzer: ON" else "Buzzer: OFF",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Filled.Lightbulb,
                                    contentDescription = null,
                                    tint = if (uiState.isLedActive) Color.Yellow else Color.Gray
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (uiState.isLedActive) "LEDs: ON" else "LEDs: OFF",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }
            }

            // ==========================================
            // SECCIÓN 2: SIMULADOR DE SENSORES
            // ==========================================
            item {
                Text(
                    text = "Simulador de Sensores (Hardware Virtual IoT)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
            }

            // Simulación HC-SR04
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Sensors, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Sensor Ultrasónico HC-SR04", style = MaterialTheme.typography.titleMedium)
                            }
                            Text(
                                "${String.format(Locale.US, "%.1f", uiState.simulatedDistanceCm)} cm",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Slider(
                            value = uiState.simulatedDistanceCm,
                            onValueChange = { viewModel.setSimulatedDistance(it) },
                            valueRange = 5f..300f,
                            enabled = !uiState.isAutoSimulatingSensors
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("5 cm", style = MaterialTheme.typography.labelSmall)
                            FilterChip(
                                selected = uiState.isAutoSimulatingSensors,
                                onClick = { viewModel.toggleAutoSimulation(!uiState.isAutoSimulatingSensors) },
                                label = { Text("Variación Auto") },
                                leadingIcon = { Icon(Icons.Filled.AutoMode, contentDescription = null, Modifier.size(16.dp)) }
                            )
                            Text("300 cm", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }

            // Simulación PIR HC-SR501
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Filled.DirectionsRun,
                                contentDescription = null,
                                tint = if (uiState.simulatedPirDetected) Color.Red else Color.Green,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Sensor PIR HC-SR501", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    text = if (uiState.simulatedPirDetected) "Movimiento Simulado" else "Sin Movimiento",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }

                        Switch(
                            checked = uiState.simulatedPirDetected,
                            onCheckedChange = { viewModel.toggleSimulatedPir(it) }
                        )
                    }
                }
            }

            // ==========================================
            // SECCIÓN 3: LOG DE TRAZABILIDAD LOCAL
            // ==========================================
            item {
                Text(
                    text = "Log de Eventos en Nodo (SQLite)",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (events.isEmpty()) {
                item {
                    Text(
                        text = "Sin eventos en el nodo.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(events) { event ->
                    NodeEventLogItem(event)
                }
            }
        }
    }
}

@Composable
private fun NodeEventLogItem(event: EventLog) {
    val dateFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }
    val timeStr = dateFormat.format(Date(event.timestamp))

    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(MaterialTheme.colorScheme.secondaryContainer)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = event.eventType,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(event.description, style = MaterialTheme.typography.bodySmall)
                Text(timeStr, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
