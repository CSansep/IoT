package com.ti3042.iotaccess.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.ti3042.iotaccess.data.entity.User

/**
 * DAO para operaciones CRUD de usuarios.
 *
 * ISO 27001 (A.9.2 - Gestión de acceso de usuarios & A.9.4.2 - Procedimientos de conexión seguros):
 * Proporciona métodos para registrar, autenticar, bloquear tras 3 intentos fallidos y actualizar contraseñas.
 */
@Dao
interface UserDao {

    /** Inserta un nuevo usuario. Si ya existe (por username), lo ignora. */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertUser(user: User): Long

    /** Busca un usuario por nombre de usuario. Retorna null si no existe. */
    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    suspend fun findByUsername(username: String): User?

    /** Actualiza el contador de intentos fallidos y el estado de bloqueo de la cuenta. */
    @Query("UPDATE users SET failedAttempts = :attempts, isLocked = :isLocked WHERE id = :userId")
    suspend fun updateLockout(userId: Long, attempts: Int, isLocked: Boolean)

    /** Restablece los intentos fallidos a 0 tras un inicio de sesión exitoso. */
    @Query("UPDATE users SET failedAttempts = 0 WHERE id = :userId")
    suspend fun resetFailedAttempts(userId: Long)

    /** Actualiza la contraseña y rol de un usuario existente. */
    @Query("UPDATE users SET passwordHash = :passwordHash, role = :role, failedAttempts = 0, isLocked = 0 WHERE id = :userId")
    suspend fun updateUserPasswordAndRole(userId: Long, passwordHash: String, role: String)

    /** Obtiene todos los usuarios registrados (para auditoría). */
    @Query("SELECT * FROM users ORDER BY createdAt DESC")
    suspend fun getAllUsers(): List<User>

    /** Verifica la cantidad de usuarios registrados en la base de datos. */
    @Query("SELECT COUNT(*) FROM users")
    suspend fun getUserCount(): Int

    /** Elimina todos los usuarios (para reinicio limpio si se requiere). */
    @Query("DELETE FROM users")
    suspend fun deleteAllUsers()
}
