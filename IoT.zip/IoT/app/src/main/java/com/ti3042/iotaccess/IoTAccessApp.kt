package com.ti3042.iotaccess

import android.app.Application
import com.ti3042.iotaccess.data.AppDatabase
import com.ti3042.iotaccess.data.entity.User
import com.ti3042.iotaccess.network.ConnectionManager
import com.ti3042.iotaccess.security.CryptoUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Clase Application principal del sistema IoT Control de Accesos.
 *
 * Actúa como Service Locator sencillo para proveer acceso global a:
 * - Base de datos Room (AppDatabase).
 * - Gestor de conexión (ConnectionManager).
 * - Datos de sesión del usuario actual.
 *
 * Pre-registra exactamente las dos cuentas iniciales obligatorias:
 * 1. Usuario: admin | Contraseña: AdministradoR1234 | Rol: ADMIN
 * 2. Usuario: operador | Contraseña: Activador2026 | Rol: OPERADOR
 */
class IoTAccessApp : Application() {

    /** Base de datos Room (Singleton). */
    lateinit var database: AppDatabase
        private set

    /** Gestor de conexión TCP/Bluetooth (creado bajo demanda). */
    var connectionManager: ConnectionManager? = null

    /** Nombre del usuario actual autenticado. */
    var currentUsername: String? = null

    /** Rol del usuario actual en el sistema (ADMIN / OPERADOR). */
    var currentUserRole: String? = null

    /** Rol de dispositivo seleccionado: "panel" o "nodo". */
    var currentRole: String? = null

    /** Scope de coroutines para operaciones de inicialización. */
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()

        // Inicializar base de datos Room
        database = AppDatabase.getInstance(this)

        // Pre-registrar usuarios por defecto
        appScope.launch {
            preRegisterDefaultUsers()
        }
    }

    /**
     * Pre-registra y asegura la configuración exacta de usuarios por defecto:
     * - admin / AdministradoR1234 (Rol ADMIN)
     * - operador / Activador2026 (Rol OPERADOR)
     *
     * Las contraseñas se almacenan hasheadas con SHA-256 + Salt (ISO 27001).
     */
    private suspend fun preRegisterDefaultUsers() {
        val userDao = database.userDao()

        // 1. Usuario 'admin'
        val adminUser = userDao.findByUsername("admin")
        if (adminUser == null) {
            userDao.insertUser(
                User(
                    username = "admin",
                    passwordHash = CryptoUtils.hashPassword("AdministradoR1234"),
                    role = "ADMIN",
                    failedAttempts = 0,
                    isLocked = false
                )
            )
        } else if (!CryptoUtils.verifyPassword("AdministradoR1234", adminUser.passwordHash) || adminUser.isLocked) {
            userDao.updateUserPasswordAndRole(
                userId = adminUser.id,
                passwordHash = CryptoUtils.hashPassword("AdministradoR1234"),
                role = "ADMIN"
            )
        }

        // 2. Usuario 'operador'
        val operadorUser = userDao.findByUsername("operador")
        if (operadorUser == null) {
            userDao.insertUser(
                User(
                    username = "operador",
                    passwordHash = CryptoUtils.hashPassword("Activador2026"),
                    role = "OPERADOR",
                    failedAttempts = 0,
                    isLocked = false
                )
            )
        } else if (!CryptoUtils.verifyPassword("Activador2026", operadorUser.passwordHash) || operadorUser.isLocked) {
            userDao.updateUserPasswordAndRole(
                userId = operadorUser.id,
                passwordHash = CryptoUtils.hashPassword("Activador2026"),
                role = "OPERADOR"
            )
        }
    }

    /**
     * Crea o recrea el ConnectionManager con la frase de cifrado especificada.
     *
     * @param passphrase Frase secreta compartida para AES-256.
     * @return ConnectionManager configurado.
     */
    fun createConnectionManager(passphrase: String = "TI3042-IoT-SecureKey-2024"): ConnectionManager {
        connectionManager?.destroy()
        val manager = ConnectionManager(this, passphrase)
        connectionManager = manager
        return manager
    }

    override fun onTerminate() {
        super.onTerminate()
        connectionManager?.destroy()
    }
}
