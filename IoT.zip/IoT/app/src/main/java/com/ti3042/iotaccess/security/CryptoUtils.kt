package com.ti3042.iotaccess.security

import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Utilidades criptográficas para seguridad del sistema IoT.
 *
 * Implementa los controles de seguridad según:
 * - ISO 27001 (A.10.1 - Controles criptográficos & A.9.4.2 - Conexión segura): Hashing y cifrado robusto.
 * - ISO 27400 (Seguridad IoT): Cifrado de datos en tránsito entre dispositivos.
 * - Lineamientos OT: Protección de tramas de comandos en redes industriales.
 *
 * Funcionalidades:
 * 1. Validación estricta de robustez de contraseñas (mínimo 8 caracteres alfanuméricos con mayúscula, minúscula y número).
 * 2. Hashing SHA-256 con Salt aleatorio para almacenamiento seguro de contraseñas.
 * 3. Cifrado simétrico AES-256-CBC para encriptar tramas de comunicación.
 */
object CryptoUtils {

    // ===================================================================
    // CONSTANTES DE CONFIGURACIÓN CRIPTOGRÁFICA
    // ===================================================================

    /** Tamaño del salt en bytes (16 bytes = 128 bits). */
    private const val SALT_LENGTH = 16

    /** Algoritmo de hashing para contraseñas. */
    private const val HASH_ALGORITHM = "SHA-256"

    /** Algoritmo de cifrado simétrico con modo CBC y padding PKCS5. */
    private const val CIPHER_ALGORITHM = "AES/CBC/PKCS5Padding"

    /** Tamaño de la clave AES en bytes (32 bytes = 256 bits). */
    private const val AES_KEY_LENGTH = 32

    /** Tamaño del vector de inicialización (IV) en bytes. */
    private const val IV_LENGTH = 16

    /** Generador de números aleatorios criptográficamente seguro. */
    private val secureRandom = SecureRandom()

    // ===================================================================
    // VALIDACIÓN DE CONTRASEÑAS ROBUSTAS (ISO 27001 / OT)
    // ===================================================================

    /**
     * Valida si una contraseña cumple estrictamente con la política de seguridad:
     * - Mínimo 8 caracteres de longitud.
     * - Al menos una letra mayúscula (A-Z).
     * - Al menos una letra minúscula (a-z).
     * - Al menos un dígito numérico (0-9).
     *
     * @param password Contraseña en texto plano a verificar.
     * @return true si cumple con todos los requisitos, false en caso contrario.
     */
    fun isPasswordRobust(password: String): Boolean {
        if (password.length < 8) return false
        val hasUpper = password.any { it.isUpperCase() }
        val hasLower = password.any { it.isLowerCase() }
        val hasDigit = password.any { it.isDigit() }
        return hasUpper && hasLower && hasDigit
    }

    // ===================================================================
    // HASHING DE CONTRASEÑAS (SHA-256 + Salt)
    // ISO 27001 A.9.4 - Control de acceso a sistemas y aplicaciones
    // ===================================================================

    /**
     * Genera un hash seguro de la contraseña con salt aleatorio.
     *
     * El salt previene ataques de tabla arcoíris (rainbow table).
     * Formato de salida: "saltHex:hashHex"
     *
     * @param password Contraseña en texto plano a hashear.
     * @return Cadena en formato "saltHex:hashHex" para almacenar en la BD.
     */
    fun hashPassword(password: String): String {
        // Generar salt aleatorio de 16 bytes
        val salt = ByteArray(SALT_LENGTH)
        secureRandom.nextBytes(salt)

        // Calcular SHA-256(salt + password)
        val digest = MessageDigest.getInstance(HASH_ALGORITHM)
        digest.update(salt)
        val hash = digest.digest(password.toByteArray(Charsets.UTF_8))

        // Retornar en formato "saltHex:hashHex"
        return "${salt.toHex()}:${hash.toHex()}"
    }

    /**
     * Verifica una contraseña contra el hash almacenado.
     *
     * Extrae el salt del hash almacenado, recalcula el hash con la contraseña
     * proporcionada y compara de forma segura (tiempo constante).
     *
     * @param password Contraseña en texto plano a verificar.
     * @param storedHash Hash almacenado en formato "saltHex:hashHex".
     * @return true si la contraseña coincide, false en caso contrario.
     */
    fun verifyPassword(password: String, storedHash: String): Boolean {
        return try {
            val parts = storedHash.split(":")
            if (parts.size != 2) return false

            val salt = parts[0].hexToBytes()
            val expectedHash = parts[1].hexToBytes()

            // Recalcular el hash con el salt original
            val digest = MessageDigest.getInstance(HASH_ALGORITHM)
            digest.update(salt)
            val actualHash = digest.digest(password.toByteArray(Charsets.UTF_8))

            // Comparación en tiempo constante para prevenir ataques de temporización
            MessageDigest.isEqual(expectedHash, actualHash)
        } catch (e: Exception) {
            false
        }
    }

    // ===================================================================
    // CIFRADO SIMÉTRICO AES-256-CBC
    // ISO 27400 - Seguridad de datos en tránsito para IoT
    // ===================================================================

    /**
     * Deriva una clave AES-256 a partir de una frase secreta compartida.
     *
     * Ambos dispositivos deben usar la misma frase para comunicarse.
     * Se aplica SHA-256 sobre la frase para obtener exactamente 32 bytes.
     *
     * @param passphrase Frase secreta compartida entre dispositivos.
     * @return SecretKeySpec de 256 bits para AES.
     */
    fun deriveKey(passphrase: String): SecretKeySpec {
        val digest = MessageDigest.getInstance(HASH_ALGORITHM)
        val keyBytes = digest.digest(passphrase.toByteArray(Charsets.UTF_8))
        // SHA-256 produce exactamente 32 bytes = 256 bits para AES-256
        return SecretKeySpec(keyBytes.copyOf(AES_KEY_LENGTH), "AES")
    }

    /**
     * Encripta un mensaje de texto plano con AES-256-CBC.
     *
     * Genera un IV aleatorio para cada mensaje (semántica de cifrado).
     * El resultado incluye el IV prepended al texto cifrado.
     *
     * Formato de salida: [IV (16 bytes)][CipherText (N bytes)]
     *
     * @param plaintext Texto plano a cifrar (trama de comando/telemetría).
     * @param key Clave AES-256 derivada con [deriveKey].
     * @return ByteArray con IV + texto cifrado.
     */
    fun encrypt(plaintext: String, key: SecretKeySpec): ByteArray {
        // Generar IV aleatorio para cada mensaje
        val iv = ByteArray(IV_LENGTH)
        secureRandom.nextBytes(iv)
        val ivSpec = IvParameterSpec(iv)

        // Cifrar con AES-256-CBC
        val cipher = Cipher.getInstance(CIPHER_ALGORITHM)
        cipher.init(Cipher.ENCRYPT_MODE, key, ivSpec)
        val encrypted = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))

        // Concatenar IV + ciphertext
        return iv + encrypted
    }

    /**
     * Desencripta un mensaje cifrado con AES-256-CBC.
     *
     * Extrae el IV de los primeros 16 bytes y descifra el resto.
     *
     * @param data ByteArray con [IV (16 bytes)][CipherText].
     * @param key Clave AES-256 derivada con [deriveKey].
     * @return Texto plano descifrado.
     * @throws Exception si la clave es incorrecta o los datos están corruptos.
     */
    fun decrypt(data: ByteArray, key: SecretKeySpec): String {
        // Extraer IV (primeros 16 bytes)
        val iv = data.copyOfRange(0, IV_LENGTH)
        val ivSpec = IvParameterSpec(iv)

        // Extraer ciphertext (resto de los bytes)
        val ciphertext = data.copyOfRange(IV_LENGTH, data.size)

        // Descifrar con AES-256-CBC
        val cipher = Cipher.getInstance(CIPHER_ALGORITHM)
        cipher.init(Cipher.DECRYPT_MODE, key, ivSpec)
        val decrypted = cipher.doFinal(ciphertext)

        return String(decrypted, Charsets.UTF_8)
    }

    // ===================================================================
    // UTILIDADES DE CONVERSIÓN HEX
    // ===================================================================

    /** Convierte ByteArray a cadena hexadecimal. */
    private fun ByteArray.toHex(): String =
        joinToString("") { "%02x".format(it) }

    /** Convierte cadena hexadecimal a ByteArray. */
    private fun String.hexToBytes(): ByteArray {
        check(length % 2 == 0) { "La cadena hex debe tener longitud par" }
        return chunked(2).map { it.toInt(16).toByte() }.toByteArray()
    }
}
