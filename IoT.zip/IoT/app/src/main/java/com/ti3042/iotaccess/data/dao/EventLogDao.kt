package com.ti3042.iotaccess.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.ti3042.iotaccess.data.entity.EventLog
import kotlinx.coroutines.flow.Flow

/**
 * DAO para el registro de eventos (log de trazabilidad).
 *
 * ISO 27001 (A.12.4 - Registro y monitoreo):
 * Permite insertar y consultar eventos para auditoría del sistema IoT.
 */
@Dao
interface EventLogDao {

    /** Inserta un nuevo evento en el log. */
    @Insert
    suspend fun insertEvent(event: EventLog)

    /**
     * Obtiene los últimos N eventos como Flow reactivo.
     * Se actualiza automáticamente al insertar nuevos registros.
     */
    @Query("SELECT * FROM event_logs ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentEvents(limit: Int = 100): Flow<List<EventLog>>

    /** Obtiene todos los eventos de un tipo específico. */
    @Query("SELECT * FROM event_logs WHERE eventType = :type ORDER BY timestamp DESC")
    fun getEventsByType(type: String): Flow<List<EventLog>>

    /** Elimina eventos anteriores a una fecha (limpieza periódica). */
    @Query("DELETE FROM event_logs WHERE timestamp < :beforeTimestamp")
    suspend fun deleteOldEvents(beforeTimestamp: Long)

    /** Cuenta total de eventos registrados. */
    @Query("SELECT COUNT(*) FROM event_logs")
    suspend fun getEventCount(): Int
}

