package com.ti3042.iotaccess

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.ti3042.iotaccess.ui.connection.ConnectionScreen
import com.ti3042.iotaccess.ui.connection.ConnectionViewModel
import com.ti3042.iotaccess.ui.login.LoginScreen
import com.ti3042.iotaccess.ui.login.LoginViewModel
import com.ti3042.iotaccess.ui.node.NodeScreen
import com.ti3042.iotaccess.ui.node.NodeViewModel
import com.ti3042.iotaccess.ui.panel.PanelScreen
import com.ti3042.iotaccess.ui.panel.PanelViewModel
import com.ti3042.iotaccess.ui.roles.RoleSelectionScreen
import com.ti3042.iotaccess.ui.theme.IoTAccessTheme

/**
 * Actividad principal del Sistema de Control de Accesos y Monitoreo Perimetral (TI3042).
 *
 * Implementa la navegación completa entre pantallas usando Jetpack Compose Navigation:
 * 1. Login/Registro: Autenticación con hash SHA-256 + Salt (ISO 27001).
 * 2. Selección de Rol: Modo Panel de Control (Central) o Modo Nodo Perimetral (Simulador IoT).
 * 3. Conexión Inalámbrica: Wi-Fi TCP Sockets o Bluetooth Classic RFCOMM con cifrado AES-256.
 * 4. Pantalla de Operación según el rol:
 *    - Panel: Monitoreo en tiempo real (HC-SR04, PIR, Log SQLite) y Controles de Activador.
 *    - Nodo: Simulador virtual de hardware IoT con respuesta a actuadores remotos.
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val app = application as IoTAccessApp

        setContent {
            IoTAccessTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppNavigation(app = app)
                }
            }
        }
    }
}

/**
 * Grafo de navegación central de la aplicación.
 */
@Composable
fun AppNavigation(app: IoTAccessApp) {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "login"
    ) {
        // 1. Pantalla de Autenticación (Login / Registro con SHA-256 + Salt)
        composable("login") {
            val loginViewModel: LoginViewModel = viewModel()
            LoginScreen(
                viewModel = loginViewModel,
                onLoginSuccess = {
                    navController.navigate("roles") {
                        popUpTo("login") { inclusive = true }
                    }
                }
            )
        }

        // 2. Pantalla de Selección de Rol (Panel de Control o Nodo Perimetral)
        composable("roles") {
            RoleSelectionScreen(
                username = app.currentUsername ?: "Operador",
                onSelectPanel = {
                    app.currentRole = "panel"
                    navController.navigate("connection")
                },
                onSelectNodo = {
                    app.currentRole = "nodo"
                    navController.navigate("connection")
                }
            )
        }

        // 3. Pantalla de Conexión (Wi-Fi TCP / Bluetooth RFCOMM)
        composable("connection") {
            val connectionViewModel: ConnectionViewModel = viewModel()
            val currentRole = app.currentRole ?: "panel"
            ConnectionScreen(
                viewModel = connectionViewModel,
                role = currentRole,
                onConnected = {
                    val destination = if (currentRole == "nodo") "nodo" else "panel"
                    navController.navigate(destination) {
                        popUpTo("connection") { inclusive = true }
                    }
                }
            )
        }

        // 4. Modo Panel de Control (Central de Monitoreo y Activador)
        composable("panel") {
            val panelViewModel: PanelViewModel = viewModel()
            PanelScreen(
                viewModel = panelViewModel,
                onDisconnect = {
                    navController.navigate("roles") {
                        popUpTo("panel") { inclusive = true }
                    }
                }
            )
        }

        // 5. Modo Nodo Perimetral (Simulador de Hardware IoT)
        composable("nodo") {
            val nodeViewModel: NodeViewModel = viewModel()
            NodeScreen(
                viewModel = nodeViewModel,
                onDisconnect = {
                    navController.navigate("roles") {
                        popUpTo("nodo") { inclusive = true }
                    }
                }
            )
        }
    }
}
