package com.ti3042.iotaccess.ui.login

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ti3042.iotaccess.IoTAccessApp
import com.ti3042.iotaccess.data.entity.EventLog
import com.ti3042.iotaccess.data.entity.User
import com.ti3042.iotaccess.security.CryptoUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * ViewModel para la pantalla de Login / Registro.
 *
 * Gestiona:
 * 1. Autenticación con verificación SHA-256 + Salt.
 * 2. Bloqueo automático estricto de la cuenta tras 3 intentos fallidos consecutivos (ISO 27001 A.9.4.2).
 * 3. Validación estricta de contraseñas robustas (mínimo 8 caracteres, al menos 1 mayúscula, 1 minúscula y 1 número).
 * 4. Registro de nuevos usuarios con rol OPERADOR y contraseña cifrada.
 */
class LoginViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as IoTAccessApp
    private val userDao = app.database.userDao()
    private val eventLogDao = app.database.eventLogDao()

    /** Estado de la UI del Login. */
    data class LoginUiState(
        val username: String = "",
        val password: String = "",
        val isRegistering: Boolean = false,  // true = modo registro, false = modo login
        val isLoading: Boolean = false,
        val errorMessage: String? = null,
        val loginSuccess: Boolean = false
    )

    private val _uiState = MutableStateFlow(LoginUiState())
    val uiState: StateFlow<LoginUiState> = _uiState.asStateFlow()

    // ===================================================================
    // ACTUALIZACIÓN DE CAMPOS DE TEXTO
    // ===================================================================

    fun updateUsername(value: String) {
        _uiState.value = _uiState.value.copy(username = value, errorMessage = null)
    }

    fun updatePassword(value: String) {
        _uiState.value = _uiState.value.copy(password = value, errorMessage = null)
    }

    /** Alterna entre modo Login y modo Registro. */
    fun toggleRegistering() {
        _uiState.value = _uiState.value.copy(
            isRegistering = !_uiState.value.isRegistering,
            errorMessage = null
        )
    }

    // ===================================================================
    // AUTENTICACIÓN E INICIO DE SESIÓN (LÍMITE ESTRICTO DE 3 INTENTOS)
    // ===================================================================

    /**
     * Intenta iniciar sesión con las credenciales ingresadas.
     * Verifica la contraseña con SHA-256 + Salt y bloquea la cuenta tras 3 intentos fallidos.
     */
    fun login() {
        val state = _uiState.value
        if (state.username.isBlank() || state.password.isBlank()) {
            _uiState.value = state.copy(errorMessage = "Complete todos los campos")
            return
        }

        _uiState.value = state.copy(isLoading = true, errorMessage = null)

        viewModelScope.launch {
            try {
                val user = userDao.findByUsername(state.username.trim())

                if (user == null) {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = "Usuario no encontrado"
                    )
                    logAuthEvent("LOGIN_FAILED", "Usuario no encontrado: ${state.username}")
                    return@launch
                }

                // Verificar si la cuenta ya está bloqueada por 3 intentos fallidos
                if (user.isLocked) {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = "Cuenta bloqueada por seguridad tras 3 intentos fallidos. Contacte al administrador."
                    )
                    logAuthEvent("BLOCKED_ACCESS", "Intento de acceso a cuenta bloqueada: ${user.username}")
                    return@launch
                }

                // Verificar contraseña con hash SHA-256 + Salt
                if (CryptoUtils.verifyPassword(state.password, user.passwordHash)) {
                    // Restablecer contador de intentos fallidos
                    userDao.resetFailedAttempts(user.id)

                    // Autenticación exitosa
                    app.currentUsername = user.username
                    app.currentUserRole = user.role
                    logAuthEvent("LOGIN_OK", "Inicio de sesión exitoso: ${user.username} [${user.role}]")
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        loginSuccess = true
                    )
                } else {
                    // Contraseña incorrecta: incrementar contador de intentos fallidos
                    val newAttempts = user.failedAttempts + 1
                    val isNowLocked = newAttempts >= 3

                    userDao.updateLockout(user.id, newAttempts, isNowLocked)

                    if (isNowLocked) {
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            errorMessage = "Cuenta bloqueada por seguridad tras 3 intentos fallidos consecutivos"
                        )
                        logAuthEvent("ACCOUNT_LOCKED", "Cuenta bloqueada tras 3 intentos fallidos: ${user.username}")
                    } else {
                        val remaining = 3 - newAttempts
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            errorMessage = "Contraseña incorrecta. Intento $newAttempts de 3 ($remaining restante${if (remaining == 1) "" else "s"})"
                        )
                        logAuthEvent("LOGIN_FAILED", "Intento fallido $newAttempts/3 para: ${user.username}")
                    }
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = "Error: ${e.localizedMessage}"
                )
            }
        }
    }

    // ===================================================================
    // REGISTRO DE NUEVO USUARIO (VALIDACIÓN ESTRICTA DE CONTRASEÑA)
    // ===================================================================

    /**
     * Registra un nuevo usuario en la base de datos previa validación robusta:
     * - Mínimo 8 caracteres alfanuméricos.
     * - Al menos una letra mayúscula, una minúscula y un número.
     */
    fun register() {
        val state = _uiState.value
        if (state.username.isBlank() || state.password.isBlank()) {
            _uiState.value = state.copy(errorMessage = "Complete todos los campos")
            return
        }

        // Validación estricta de política de contraseñas robustas
        if (!CryptoUtils.isPasswordRobust(state.password)) {
            _uiState.value = state.copy(
                errorMessage = "La contraseña debe tener mínimo 8 caracteres alfanuméricos y contener al menos una mayúscula, una minúscula y un número"
            )
            return
        }

        _uiState.value = state.copy(isLoading = true, errorMessage = null)

        viewModelScope.launch {
            try {
                // Verificar si el usuario ya existe
                val existing = userDao.findByUsername(state.username.trim())
                if (existing != null) {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = "El usuario '${state.username}' ya existe"
                    )
                    return@launch
                }

                // Hashear contraseña con SHA-256 + Salt (ISO 27001 A.10.1)
                val hashedPassword = CryptoUtils.hashPassword(state.password)

                // Insertar nuevo usuario
                val newUser = User(
                    username = state.username.trim(),
                    passwordHash = hashedPassword,
                    role = "OPERADOR",
                    failedAttempts = 0,
                    isLocked = false
                )
                userDao.insertUser(newUser)

                logAuthEvent("REGISTER_OK", "Nuevo usuario registrado: ${state.username}")
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    isRegistering = false,
                    errorMessage = null,
                    password = ""
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = "Error al registrar: ${e.localizedMessage}"
                )
            }
        }
    }

    /**
     * Registra un evento de autenticación en el log de trazabilidad SQLite.
     */
    private suspend fun logAuthEvent(type: String, description: String) {
        eventLogDao.insertEvent(
            EventLog(
                eventType = "AUTH",
                description = "[$type] $description",
                deviceRole = "SYSTEM"
            )
        )
    }
}
