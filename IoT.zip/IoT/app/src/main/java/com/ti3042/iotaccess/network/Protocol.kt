package com.ti3042.iotaccess.network

import org.json.JSONObject

/**
 * Protocolo de comunicación entre Panel de Control y Nodo Perimetral.
 *
 * Define la estructura de mensajes intercambiados entre dispositivos Android.
 * Todos los mensajes se serializan a JSON, se cifran con AES-256 y se envían
 * por TCP/Wi-Fi o Bluetooth RFCOMM.
 *
 * ISO 27400: Las tramas viajan cifradas para proteger comandos OT.
 *
 * Formato en la red: [4 bytes: longitud del payload][payload cifrado AES-256]
 */
object Protocol {

    // ===================================================================
    // TIPOS DE MENSAJE
    // ===================================================================

    /** Comando enviado desde el Panel de Control al Nodo. */
    const val TYPE_COMMAND = "COMMAND"

    /** Telemetría enviada desde el Nodo al Panel. */
    const val TYPE_TELEMETRY = "TELEMETRY"

    /** Estado completo del Nodo enviado al Panel. */
    const val TYPE_STATUS = "STATUS"

    /** Confirmación de recepción. */
    const val TYPE_ACK = "ACK"

    // ===================================================================
    // ACCIONES DE COMANDO (Panel → Nodo)
    // ===================================================================

    const val ACTION_ARM = "ARM"               // Armar sistema
    const val ACTION_DISARM = "DISARM"         // Desarmar sistema
    const val ACTION_BUZZER_ON = "BUZZER_ON"   // Activar buzzer
    const val ACTION_BUZZER_OFF = "BUZZER_OFF" // Desactivar buzzer
    const val ACTION_LED_ON = "LED_ON"         // Activar LEDs de alerta
    const val ACTION_LED_OFF = "LED_OFF"       // Desactivar LEDs
    const val ACTION_SET_SERVO = "SET_SERVO"   // Mover servomotor SG90
    const val ACTION_SET_ALERT_DIST = "SET_ALERT_DIST" // Configurar distancia crítica
    const val ACTION_HEARTBEAT = "HEARTBEAT"   // Latido de conexión

    // ===================================================================
    // CLAVES JSON
    // ===================================================================

    private const val KEY_TYPE = "type"
    private const val KEY_ACTION = "action"
    private const val KEY_DATA = "data"
    private const val KEY_TIMESTAMP = "timestamp"
    private const val KEY_ULTRASONIC_CM = "ultrasonicCm"
    private const val KEY_PIR_DETECTED = "pirDetected"
    private const val KEY_ARMED = "armed"
    private const val KEY_BUZZER_ACTIVE = "buzzerActive"
    private const val KEY_LED_ACTIVE = "ledActive"
    private const val KEY_SERVO_ANGLE = "servoAngle"
    private const val KEY_ALERT_DISTANCE_CM = "alertDistanceCm"
    private const val KEY_ANGLE = "angle"
    private const val KEY_DISTANCE_CM = "distanceCm"

    // ===================================================================
    // DATA CLASSES PARA MENSAJES TIPADOS
    // ===================================================================

    /** Datos de telemetría del Nodo Perimetral. */
    data class TelemetryData(
        val ultrasonicCm: Float,  // Distancia HC-SR04 en cm
        val pirDetected: Boolean, // Estado PIR HC-SR501
        val timestamp: Long = System.currentTimeMillis()
    )

    /** Estado completo del Nodo Perimetral. */
    data class NodeStatus(
        val armed: Boolean,
        val buzzerActive: Boolean,
        val ledActive: Boolean,
        val servoAngle: Int,
        val alertDistanceCm: Float
    )

    /** Mensaje genérico del protocolo. */
    data class Message(
        val type: String,
        val action: String = "",
        val data: JSONObject = JSONObject()
    )

    // ===================================================================
    // SERIALIZACIÓN: Objetos → JSON String
    // ===================================================================

    /** Crea un mensaje de comando (Panel → Nodo). */
    fun createCommand(action: String, data: JSONObject = JSONObject()): String {
        val json = JSONObject().apply {
            put(KEY_TYPE, TYPE_COMMAND)
            put(KEY_ACTION, action)
            put(KEY_DATA, data)
            put(KEY_TIMESTAMP, System.currentTimeMillis())
        }
        return json.toString()
    }

    /** Crea un comando para mover el servomotor. */
    fun createServoCommand(angle: Int): String {
        val data = JSONObject().apply { put(KEY_ANGLE, angle) }
        return createCommand(ACTION_SET_SERVO, data)
    }

    /** Crea un comando para configurar la distancia crítica. */
    fun createAlertDistanceCommand(distanceCm: Float): String {
        val data = JSONObject().apply { put(KEY_DISTANCE_CM, distanceCm) }
        return createCommand(ACTION_SET_ALERT_DIST, data)
    }

    /** Crea un mensaje de telemetría (Nodo → Panel). */
    fun createTelemetry(telemetry: TelemetryData): String {
        val data = JSONObject().apply {
            put(KEY_ULTRASONIC_CM, telemetry.ultrasonicCm.toDouble())
            put(KEY_PIR_DETECTED, telemetry.pirDetected)
        }
        val json = JSONObject().apply {
            put(KEY_TYPE, TYPE_TELEMETRY)
            put(KEY_DATA, data)
            put(KEY_TIMESTAMP, telemetry.timestamp)
        }
        return json.toString()
    }

    /** Crea un mensaje de estado completo (Nodo → Panel). */
    fun createStatus(status: NodeStatus): String {
        val data = JSONObject().apply {
            put(KEY_ARMED, status.armed)
            put(KEY_BUZZER_ACTIVE, status.buzzerActive)
            put(KEY_LED_ACTIVE, status.ledActive)
            put(KEY_SERVO_ANGLE, status.servoAngle)
            put(KEY_ALERT_DISTANCE_CM, status.alertDistanceCm.toDouble())
        }
        val json = JSONObject().apply {
            put(KEY_TYPE, TYPE_STATUS)
            put(KEY_DATA, data)
            put(KEY_TIMESTAMP, System.currentTimeMillis())
        }
        return json.toString()
    }

    /** Crea un mensaje ACK. */
    fun createAck(): String {
        val json = JSONObject().apply {
            put(KEY_TYPE, TYPE_ACK)
            put(KEY_TIMESTAMP, System.currentTimeMillis())
        }
        return json.toString()
    }

    // ===================================================================
    // DESERIALIZACIÓN: JSON String → Objetos tipados
    // ===================================================================

    /** Parsea un mensaje JSON genérico. */
    fun parseMessage(jsonString: String): Message {
        val json = JSONObject(jsonString)
        return Message(
            type = json.optString(KEY_TYPE, ""),
            action = json.optString(KEY_ACTION, ""),
            data = json.optJSONObject(KEY_DATA) ?: JSONObject()
        )
    }

    /** Extrae datos de telemetría de un mensaje. */
    fun parseTelemetry(data: JSONObject): TelemetryData {
        return TelemetryData(
            ultrasonicCm = data.optDouble(KEY_ULTRASONIC_CM, 0.0).toFloat(),
            pirDetected = data.optBoolean(KEY_PIR_DETECTED, false),
            timestamp = System.currentTimeMillis()
        )
    }

    /** Extrae el estado completo del nodo de un mensaje. */
    fun parseStatus(data: JSONObject): NodeStatus {
        return NodeStatus(
            armed = data.optBoolean(KEY_ARMED, false),
            buzzerActive = data.optBoolean(KEY_BUZZER_ACTIVE, false),
            ledActive = data.optBoolean(KEY_LED_ACTIVE, false),
            servoAngle = data.optInt(KEY_SERVO_ANGLE, 0),
            alertDistanceCm = data.optDouble(KEY_ALERT_DISTANCE_CM, 50.0).toFloat()
        )
    }

    /** Extrae el ángulo del servo de un comando. */
    fun parseServoAngle(data: JSONObject): Int =
        data.optInt(KEY_ANGLE, 0)

    /** Extrae la distancia crítica de un comando. */
    fun parseAlertDistance(data: JSONObject): Float =
        data.optDouble(KEY_DISTANCE_CM, 50.0).toFloat()
}

