package com.ti3042.iotaccess.ui.connection

import android.app.Application
import android.bluetooth.BluetoothDevice
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ti3042.iotaccess.IoTAccessApp
import com.ti3042.iotaccess.data.entity.EventLog
import com.ti3042.iotaccess.network.ConnectionManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * ViewModel para la pantalla de configuración de conexión.
 *
 * Gestiona la conexión Wi-Fi TCP o Bluetooth RFCOMM entre dispositivos.
 */
class ConnectionViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as IoTAccessApp
    private val eventLogDao = app.database.eventLogDao()

    /** Estado de la UI de conexión. */
    data class ConnectionUiState(
        val connectionType: String = "wifi",        // "wifi" o "bluetooth"
        val isServer: Boolean = true,               // true=Servidor, false=Cliente
        val ipAddress: String = "",                  // IP del servidor (modo cliente Wi-Fi)
        val port: String = "8888",                   // Puerto TCP
        val encryptionKey: String = "TI3042-IoT-SecureKey-2024", // Clave AES compartida
        val connectionState: ConnectionManager.ConnectionState =
            ConnectionManager.ConnectionState.DISCONNECTED,
        val errorMessage: String? = null,
        val pairedDevices: List<BluetoothDevice> = emptyList(),
        val selectedBtDevice: BluetoothDevice? = null,
        val isConnected: Boolean = false
    )

    private val _uiState = MutableStateFlow(ConnectionUiState(
        // El Nodo es servidor por defecto, el Panel es cliente
        isServer = app.currentRole == "nodo"
    ))
    val uiState: StateFlow<ConnectionUiState> = _uiState.asStateFlow()

    // ===================================================================
    // ACTUALIZACIÓN DE CAMPOS
    // ===================================================================

    fun setConnectionType(type: String) {
        _uiState.value = _uiState.value.copy(connectionType = type)
        if (type == "bluetooth") loadPairedDevices()
    }

    fun setIsServer(isServer: Boolean) {
        _uiState.value = _uiState.value.copy(isServer = isServer)
    }

    fun setIpAddress(ip: String) {
        _uiState.value = _uiState.value.copy(ipAddress = ip, errorMessage = null)
    }

    fun setPort(port: String) {
        _uiState.value = _uiState.value.copy(port = port, errorMessage = null)
    }

    fun setEncryptionKey(key: String) {
        _uiState.value = _uiState.value.copy(encryptionKey = key)
    }

    fun selectBluetoothDevice(device: BluetoothDevice) {
        _uiState.value = _uiState.value.copy(selectedBtDevice = device)
    }

    // ===================================================================
    // BLUETOOTH: CARGAR DISPOSITIVOS EMPAREJADOS
    // ===================================================================

    fun loadPairedDevices() {
        val manager = app.connectionManager ?: app.createConnectionManager()
        val devices = manager.getPairedBluetoothDevices()
        _uiState.value = _uiState.value.copy(pairedDevices = devices)
    }

    // ===================================================================
    // CONECTAR
    // ===================================================================

    /**
     * Inicia la conexión según la configuración actual.
     */
    fun connect() {
        val state = _uiState.value

        // Crear ConnectionManager con la clave de cifrado configurada
        val manager = app.createConnectionManager(state.encryptionKey)

        // Observar cambios de estado de conexión
        viewModelScope.launch {
            manager.connectionState.collect { connState ->
                _uiState.value = _uiState.value.copy(
                    connectionState = connState,
                    isConnected = connState == ConnectionManager.ConnectionState.CONNECTED,
                    errorMessage = null
                )
            }
        }

        // Observar errores
        viewModelScope.launch {
            manager.errorMessage.collect { error ->
                if (error != null) {
                    _uiState.value = _uiState.value.copy(errorMessage = error)
                }
            }
        }

        // Iniciar conexión según tipo y modo
        when {
            state.connectionType == "wifi" && state.isServer -> {
                val port = state.port.toIntOrNull() ?: 8888
                manager.startWifiServer(port)
                logConnectionEvent("Servidor Wi-Fi iniciado en puerto $port")
            }
            state.connectionType == "wifi" && !state.isServer -> {
                if (state.ipAddress.isBlank()) {
                    _uiState.value = state.copy(errorMessage = "Ingrese la dirección IP del servidor")
                    return
                }
                val port = state.port.toIntOrNull() ?: 8888
                manager.connectWifiClient(state.ipAddress.trim(), port)
                logConnectionEvent("Conectando Wi-Fi a ${state.ipAddress}:$port")
            }
            state.connectionType == "bluetooth" && state.isServer -> {
                manager.startBluetoothServer()
                logConnectionEvent("Servidor Bluetooth RFCOMM iniciado")
            }
            state.connectionType == "bluetooth" && !state.isServer -> {
                val device = state.selectedBtDevice
                if (device == null) {
                    _uiState.value = state.copy(errorMessage = "Seleccione un dispositivo Bluetooth")
                    return
                }
                manager.connectBluetoothClient(device)
                logConnectionEvent("Conectando Bluetooth a ${device.name ?: device.address}")
            }
        }
    }

    /**
     * Desconecta la conexión actual.
     */
    fun disconnect() {
        app.connectionManager?.disconnect()
        logConnectionEvent("Desconectado manualmente")
    }

    private fun logConnectionEvent(description: String) {
        viewModelScope.launch {
            eventLogDao.insertEvent(
                EventLog(
                    eventType = "CONNECTION",
                    description = description,
                    deviceRole = app.currentRole?.uppercase() ?: "UNKNOWN"
                )
            )
        }
    }
}

