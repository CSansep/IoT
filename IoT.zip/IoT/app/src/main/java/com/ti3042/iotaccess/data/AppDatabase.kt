package com.ti3042.iotaccess.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.ti3042.iotaccess.data.dao.EventLogDao
import com.ti3042.iotaccess.data.dao.UserDao
import com.ti3042.iotaccess.data.entity.EventLog
import com.ti3042.iotaccess.data.entity.User

/**
 * Base de datos Room para el sistema de control de accesos IoT.
 *
 * Contiene dos tablas:
 * - users: Usuarios registrados con contraseñas hasheadas (SHA-256 + Salt), roles y control de bloqueo.
 * - event_logs: Registro de eventos para trazabilidad (ISO 27001 A.12.4).
 *
 * Versión 2: Incorpora control de roles y bloqueo tras 3 intentos fallidos.
 */
@Database(
    entities = [User::class, EventLog::class],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    /** DAO para operaciones con usuarios. */
    abstract fun userDao(): UserDao

    /** DAO para el log de eventos. */
    abstract fun eventLogDao(): EventLogDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        /**
         * Obtiene la instancia Singleton de la base de datos.
         * Thread-safe gracias a synchronized y @Volatile.
         */
        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "iot_access_db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
