package com.ti3042.iotaccess.network

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.util.Log
import com.ti3042.iotaccess.security.CryptoUtils
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID
import javax.crypto.spec.SecretKeySpec

/**
 * Gestor de conexión bidireccional entre dos dispositivos Android.
 *
 * Soporta dos modos de comunicación:
 * 1. Wi-Fi TCP Sockets: Comunicación por red local (IP:Puerto).
 * 2. Bluetooth Classic RFCOMM: Comunicación por emparejamiento BT.
 *
 * Características:
 * - Comunicación cifrada con AES-256 (ISO 27400).
 * - Manejo robusto de desconexiones sin que la app se cierre.
 * - Uso de Coroutines para operaciones asíncronas en tiempo real.
 * - Protocolo de longitud prefijada: [4 bytes: tamaño][payload cifrado].
 *
 * @param context Contexto de la aplicación Android.
 * @param encryptionPassphrase Frase secreta compartida para AES-256.
 */
class ConnectionManager(
    private val context: Context,
    encryptionPassphrase: String = "TI3042-IoT-SecureKey-2024"
) {
    companion object {
        private const val TAG = "ConnectionManager"

        /** UUID estándar para perfil RFCOMM SPP (Serial Port Profile). */
        private val BT_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

        /** Nombre del servicio Bluetooth para descubrimiento. */
        private const val BT_SERVICE_NAME = "IoTAccessControl"

        /** Intervalo de heartbeat para detectar desconexiones (ms). */
        private const val HEARTBEAT_INTERVAL = 5000L

        /** Timeout para leer datos antes de verificar conexión (ms). */
        private const val READ_TIMEOUT = 10000
    }

    // ===================================================================
    // ESTADOS Y FLUJOS REACTIVOS
    // ===================================================================

    /** Estados posibles de la conexión. */
    enum class ConnectionState {
        DISCONNECTED,  // Sin conexión
        LISTENING,     // Esperando conexión entrante (modo servidor)
        CONNECTING,    // Intentando conectar (modo cliente)
        CONNECTED,     // Conexión establecida
        ERROR          // Error de conexión
    }

    /** Modos de conexión soportados. */
    enum class ConnectionMode {
        WIFI_SERVER,   // Servidor TCP Wi-Fi
        WIFI_CLIENT,   // Cliente TCP Wi-Fi
        BT_SERVER,     // Servidor Bluetooth RFCOMM
        BT_CLIENT      // Cliente Bluetooth RFCOMM
    }

    // Estado actual de la conexión (observable por la UI)
    private val _connectionState = MutableStateFlow(ConnectionState.DISCONNECTED)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    // Mensajes entrantes descifrados (observable por ViewModels)
    private val _incomingMessages = MutableSharedFlow<String>(
        replay = 0,
        extraBufferCapacity = 64
    )
    val incomingMessages: SharedFlow<String> = _incomingMessages.asSharedFlow()

    // Mensaje de error legible (para mostrar en la UI)
    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    // ===================================================================
    // ESTADO INTERNO
    // ===================================================================

    /** Clave AES-256 derivada de la frase secreta compartida. */
    private val aesKey: SecretKeySpec = CryptoUtils.deriveKey(encryptionPassphrase)

    /** Scope de coroutines para operaciones de red. */
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // Streams de datos para lectura/escritura
    private var dataInput: DataInputStream? = null
    private var dataOutput: DataOutputStream? = null

    // Recursos de conexión TCP
    private var tcpServerSocket: ServerSocket? = null
    private var tcpSocket: Socket? = null

    // Recursos de conexión Bluetooth
    private var btServerSocket: BluetoothServerSocket? = null
    private var btSocket: BluetoothSocket? = null

    // Jobs de coroutines para cancelación
    private var listenJob: Job? = null
    private var readJob: Job? = null
    private var heartbeatJob: Job? = null

    // Modo actual de conexión
    private var currentMode: ConnectionMode? = null

    // ===================================================================
    // CONEXIÓN Wi-Fi TCP
    // ===================================================================

    /**
     * Inicia un servidor TCP en el puerto especificado.
     * Espera una conexión entrante del otro dispositivo.
     *
     * @param port Puerto TCP donde escuchar (ej: 8888).
     */
    fun startWifiServer(port: Int) {
        disconnect()
        currentMode = ConnectionMode.WIFI_SERVER
        _connectionState.value = ConnectionState.LISTENING
        _errorMessage.value = null

        listenJob = scope.launch {
            try {
                Log.d(TAG, "Iniciando servidor TCP en puerto $port")
                tcpServerSocket = ServerSocket(port)
                tcpServerSocket?.soTimeout = 0 // Espera indefinida

                // Esperar conexión entrante
                val clientSocket = tcpServerSocket?.accept()
                if (clientSocket != null) {
                    tcpSocket = clientSocket
                    setupStreams(
                        DataInputStream(clientSocket.getInputStream()),
                        DataOutputStream(clientSocket.getOutputStream())
                    )
                    _connectionState.value = ConnectionState.CONNECTED
                    Log.d(TAG, "Cliente TCP conectado: ${clientSocket.inetAddress}")
                    startReading()
                    startHeartbeat()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Error en servidor TCP: ${e.message}")
                handleError("Error servidor Wi-Fi: ${e.localizedMessage}")
            }
        }
    }

    /**
     * Conecta como cliente TCP a la IP y puerto especificados.
     *
     * @param host Dirección IP del servidor (ej: "192.168.1.100").
     * @param port Puerto TCP del servidor (ej: 8888).
     */
    fun connectWifiClient(host: String, port: Int) {
        disconnect()
        currentMode = ConnectionMode.WIFI_CLIENT
        _connectionState.value = ConnectionState.CONNECTING
        _errorMessage.value = null

        listenJob = scope.launch {
            try {
                Log.d(TAG, "Conectando TCP a $host:$port")
                val socket = Socket(host, port)
                socket.soTimeout = READ_TIMEOUT
                tcpSocket = socket

                setupStreams(
                    DataInputStream(socket.getInputStream()),
                    DataOutputStream(socket.getOutputStream())
                )
                _connectionState.value = ConnectionState.CONNECTED
                Log.d(TAG, "Conectado a servidor TCP $host:$port")
                startReading()
                startHeartbeat()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Error conectando TCP: ${e.message}")
                handleError("Error conexión Wi-Fi: ${e.localizedMessage}")
            }
        }
    }

    // ===================================================================
    // CONEXIÓN BLUETOOTH CLASSIC RFCOMM
    // ===================================================================

    /**
     * Inicia un servidor Bluetooth RFCOMM.
     * Espera una conexión entrante de un dispositivo emparejado.
     */
    @SuppressLint("MissingPermission")
    fun startBluetoothServer() {
        disconnect()
        currentMode = ConnectionMode.BT_SERVER
        _connectionState.value = ConnectionState.LISTENING
        _errorMessage.value = null

        listenJob = scope.launch {
            try {
                val btManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
                val btAdapter = btManager.adapter
                    ?: throw IOException("Bluetooth no disponible en este dispositivo")

                if (!btAdapter.isEnabled) {
                    throw IOException("Bluetooth está desactivado. Actívelo en Configuración.")
                }

                Log.d(TAG, "Iniciando servidor Bluetooth RFCOMM")
                btServerSocket = btAdapter.listenUsingRfcommWithServiceRecord(
                    BT_SERVICE_NAME, BT_UUID
                )

                // Esperar conexión entrante
                val socket = btServerSocket?.accept()
                if (socket != null) {
                    btSocket = socket
                    btServerSocket?.close() // Ya no necesitamos aceptar más conexiones
                    setupStreams(
                        DataInputStream(socket.inputStream),
                        DataOutputStream(socket.outputStream)
                    )
                    _connectionState.value = ConnectionState.CONNECTED
                    Log.d(TAG, "Dispositivo BT conectado: ${socket.remoteDevice?.name}")
                    startReading()
                    startHeartbeat()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Error en servidor BT: ${e.message}")
                handleError("Error servidor Bluetooth: ${e.localizedMessage}")
            }
        }
    }

    /**
     * Conecta como cliente Bluetooth RFCOMM al dispositivo emparejado.
     *
     * @param device Dispositivo Bluetooth emparejado al que conectar.
     */
    @SuppressLint("MissingPermission")
    fun connectBluetoothClient(device: BluetoothDevice) {
        disconnect()
        currentMode = ConnectionMode.BT_CLIENT
        _connectionState.value = ConnectionState.CONNECTING
        _errorMessage.value = null

        listenJob = scope.launch {
            try {
                Log.d(TAG, "Conectando BT RFCOMM a ${device.name}")

                // Cancelar descubrimiento si está activo (mejora el rendimiento)
                val btManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
                btManager.adapter?.cancelDiscovery()

                val socket = device.createRfcommSocketToServiceRecord(BT_UUID)
                btSocket = socket
                socket.connect()

                setupStreams(
                    DataInputStream(socket.inputStream),
                    DataOutputStream(socket.outputStream)
                )
                _connectionState.value = ConnectionState.CONNECTED
                Log.d(TAG, "Conectado a dispositivo BT: ${device.name}")
                startReading()
                startHeartbeat()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Error conectando BT: ${e.message}")
                handleError("Error conexión Bluetooth: ${e.localizedMessage}")
            }
        }
    }

    /**
     * Obtiene la lista de dispositivos Bluetooth emparejados.
     *
     * @return Lista de dispositivos BluetoothDevice emparejados, o lista vacía.
     */
    @SuppressLint("MissingPermission")
    fun getPairedBluetoothDevices(): List<BluetoothDevice> {
        return try {
            val btManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
            btManager.adapter?.bondedDevices?.toList() ?: emptyList()
        } catch (e: Exception) {
            Log.e(TAG, "Error obteniendo dispositivos BT: ${e.message}")
            emptyList()
        }
    }

    // ===================================================================
    // ENVÍO Y RECEPCIÓN DE MENSAJES (CIFRADOS AES-256)
    // ===================================================================

    /**
     * Envía un mensaje cifrado al otro dispositivo.
     *
     * El mensaje se cifra con AES-256-CBC y se envía con prefijo de longitud.
     * Formato: [4 bytes: longitud del payload cifrado][payload cifrado]
     *
     * @param message Mensaje JSON en texto plano a enviar.
     */
    suspend fun sendMessage(message: String) {
        withContext(Dispatchers.IO) {
            try {
                val output = dataOutput ?: throw IOException("No hay conexión establecida")

                // Cifrar el mensaje con AES-256
                val encrypted = CryptoUtils.encrypt(message, aesKey)

                // Enviar: [longitud (4 bytes Big Endian)][datos cifrados]
                synchronized(output) {
                    output.writeInt(encrypted.size)
                    output.write(encrypted)
                    output.flush()
                }

                Log.d(TAG, "Mensaje enviado (${encrypted.size} bytes cifrados)")
            } catch (e: Exception) {
                Log.e(TAG, "Error enviando mensaje: ${e.message}")
                handleDisconnection()
            }
        }
    }

    /**
     * Configura los streams de entrada/salida para la conexión.
     */
    private fun setupStreams(input: DataInputStream, output: DataOutputStream) {
        dataInput = input
        dataOutput = output
    }

    /**
     * Inicia la lectura continua de mensajes entrantes en una coroutine.
     * Los mensajes se descifran y emiten por [incomingMessages].
     */
    private fun startReading() {
        readJob = scope.launch {
            Log.d(TAG, "Iniciando lectura continua de mensajes")
            while (isActive && _connectionState.value == ConnectionState.CONNECTED) {
                try {
                    val input = dataInput ?: break

                    // Leer longitud del payload (4 bytes Big Endian)
                    val length = input.readInt()
                    if (length <= 0 || length > 1_000_000) {
                        Log.w(TAG, "Longitud de mensaje inválida: $length")
                        continue
                    }

                    // Leer payload cifrado
                    val encrypted = ByteArray(length)
                    input.readFully(encrypted)

                    // Descifrar con AES-256
                    val decrypted = CryptoUtils.decrypt(encrypted, aesKey)
                    Log.d(TAG, "Mensaje recibido y descifrado (${length} bytes)")

                    // Emitir mensaje descifrado a los observadores
                    _incomingMessages.emit(decrypted)

                } catch (e: CancellationException) {
                    throw e
                } catch (e: java.net.SocketTimeoutException) {
                    // Timeout de lectura: no es un error, solo no hay datos nuevos
                    continue
                } catch (e: Exception) {
                    if (isActive) {
                        Log.e(TAG, "Error leyendo mensaje: ${e.message}")
                        handleDisconnection()
                    }
                    break
                }
            }
        }
    }

    /**
     * Inicia un heartbeat periódico para detectar desconexiones.
     */
    private fun startHeartbeat() {
        heartbeatJob = scope.launch {
            while (isActive && _connectionState.value == ConnectionState.CONNECTED) {
                delay(HEARTBEAT_INTERVAL)
                try {
                    sendMessage(Protocol.createAck())
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Log.w(TAG, "Heartbeat fallido: ${e.message}")
                }
            }
        }
    }

    // ===================================================================
    // MANEJO DE DESCONEXIONES Y ERRORES
    // ===================================================================

    /**
     * Maneja una desconexión inesperada sin cerrar la app.
     * Cambia el estado a DISCONNECTED y limpia recursos.
     */
    private fun handleDisconnection() {
        Log.w(TAG, "Desconexión detectada. Limpiando recursos...")
        _connectionState.value = ConnectionState.DISCONNECTED
        _errorMessage.value = "Conexión perdida con el otro dispositivo"
        cleanupResources()
    }

    /**
     * Maneja un error de conexión.
     */
    private fun handleError(message: String) {
        _connectionState.value = ConnectionState.ERROR
        _errorMessage.value = message
        cleanupResources()
    }

    /**
     * Desconecta y libera todos los recursos de red.
     * Cambia el estado a DISCONNECTED.
     */
    fun disconnect() {
        Log.d(TAG, "Desconectando...")
        _connectionState.value = ConnectionState.DISCONNECTED
        _errorMessage.value = null
        cleanupResources()
    }

    /**
     * Limpia todos los recursos de conexión de forma segura.
     */
    private fun cleanupResources() {
        // Cancelar coroutines de lectura y heartbeat
        readJob?.cancel()
        readJob = null
        heartbeatJob?.cancel()
        heartbeatJob = null
        listenJob?.cancel()
        listenJob = null

        // Cerrar streams
        try { dataInput?.close() } catch (_: Exception) {}
        try { dataOutput?.close() } catch (_: Exception) {}
        dataInput = null
        dataOutput = null

        // Cerrar sockets TCP
        try { tcpSocket?.close() } catch (_: Exception) {}
        try { tcpServerSocket?.close() } catch (_: Exception) {}
        tcpSocket = null
        tcpServerSocket = null

        // Cerrar sockets Bluetooth
        try { btSocket?.close() } catch (_: Exception) {}
        try { btServerSocket?.close() } catch (_: Exception) {}
        btSocket = null
        btServerSocket = null
    }

    /**
     * Libera todos los recursos al destruir el gestor.
     * Debe llamarse en onDestroy() de la Activity/Application.
     */
    fun destroy() {
        disconnect()
        scope.cancel()
    }
}

