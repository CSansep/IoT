package com.ti3042.iotaccess.ui.node

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ti3042.iotaccess.IoTAccessApp
import com.ti3042.iotaccess.data.entity.EventLog
import com.ti3042.iotaccess.network.ConnectionManager
import com.ti3042.iotaccess.network.Protocol
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * ViewModel para el Nodo Perimetral (Simulador IoT).
 *
 * Simula el comportamiento de hardware de un nodo IoT perimetral:
 * - Sensores: Ultrasónico HC-SR04 y Movimiento PIR HC-SR501.
 * - Actuadores: Servomotor SG90 (pestillo 0°-180°), Buzzer sonoro y LEDs de advertencia.
 * - Envío periódico de telemetría al Panel de Control mediante coroutines.
 * - Recepción y ejecución de comandos cifrados en AES-256.
 */
class NodeViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as IoTAccessApp
    private val eventLogDao = app.database.eventLogDao()

    /** Flujo de historial de eventos en tiempo real desde SQLite. */
    val recentEvents: StateFlow<List<EventLog>> = eventLogDao.getRecentEvents(30)
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    /** Estado del Nodo Perimetral. */
    data class NodeUiState(
        val connectionState: ConnectionManager.ConnectionState = ConnectionManager.ConnectionState.CONNECTED,
        val simulatedDistanceCm: Float = 120f,
        val simulatedPirDetected: Boolean = false,
        val isAutoSimulatingSensors: Boolean = false,
        val isSystemArmed: Boolean = false,
        val isBuzzerActive: Boolean = false,
        val isLedActive: Boolean = false,
        val servoAngle: Int = 0,
        val alertDistanceCm: Float = 50f
    )

    private val _uiState = MutableStateFlow(NodeUiState())
    val uiState: StateFlow<NodeUiState> = _uiState.asStateFlow()

    init {
        listenIncomingCommands()
        startTelemetryLoop()
        monitorConnectionState()
    }

    /**
     * Bucle continuo de telemetría (cada 1.5s):
     * Envía lectura actual de HC-SR04 y PIR al Panel de Control cifrado con AES-256.
     */
    private fun startTelemetryLoop() {
        viewModelScope.launch {
            while (isActive) {
                delay(1500L)
                val manager = app.connectionManager ?: continue
                if (manager.connectionState.value == ConnectionManager.ConnectionState.CONNECTED) {
                    val state = _uiState.value

                    // Si la simulación automática está activa, variar la distancia simulada
                    val currentDist = if (state.isAutoSimulatingSensors) {
                        val variation = (Math.random() * 20 - 10).toFloat()
                        (state.simulatedDistanceCm + variation).coerceIn(10f, 250f)
                    } else {
                        state.simulatedDistanceCm
                    }

                    if (state.isAutoSimulatingSensors) {
                        _uiState.value = state.copy(simulatedDistanceCm = currentDist)
                    }

                    // Enviar telemetría
                    val telemetry = Protocol.TelemetryData(
                        ultrasonicCm = currentDist,
                        pirDetected = state.simulatedPirDetected
                    )
                    val json = Protocol.createTelemetry(telemetry)
                    manager.sendMessage(json)
                }
            }
        }
    }

    /**
     * Escucha comandos entrantes enviados por el Panel de Control.
     */
    private fun listenIncomingCommands() {
        val manager = app.connectionManager ?: return
        viewModelScope.launch {
            manager.incomingMessages.collect { rawJson ->
                try {
                    val msg = Protocol.parseMessage(rawJson)
                    if (msg.type == Protocol.TYPE_COMMAND) {
                        handleCommand(msg.action, msg.data)
                    }
                } catch (e: Exception) {
                    logEvent("ERROR", "Error al procesar comando: ${e.message}")
                }
            }
        }
    }

    /**
     * Procesa la acción recibida del Panel.
     */
    private fun handleCommand(action: String, data: org.json.JSONObject) {
        val currentState = _uiState.value
        when (action) {
            Protocol.ACTION_ARM -> {
                _uiState.value = currentState.copy(isSystemArmed = true)
                logEvent("COMMAND", "Comando recibido: Sistema ARMADO")
            }
            Protocol.ACTION_DISARM -> {
                _uiState.value = currentState.copy(
                    isSystemArmed = false,
                    isBuzzerActive = false,
                    isLedActive = false
                )
                logEvent("COMMAND", "Comando recibido: Sistema DESARMADO")
            }
            Protocol.ACTION_BUZZER_ON -> {
                _uiState.value = currentState.copy(isBuzzerActive = true)
                logEvent("COMMAND", "Comando recibido: Buzzer ACTIVADO")
            }
            Protocol.ACTION_BUZZER_OFF -> {
                _uiState.value = currentState.copy(isBuzzerActive = false)
                logEvent("COMMAND", "Comando recibido: Buzzer DESACTIVADO")
            }
            Protocol.ACTION_LED_ON -> {
                _uiState.value = currentState.copy(isLedActive = true)
                logEvent("COMMAND", "Comando recibido: LEDs ACTIVADOS")
            }
            Protocol.ACTION_LED_OFF -> {
                _uiState.value = currentState.copy(isLedActive = false)
                logEvent("COMMAND", "Comando recibido: LEDs DESACTIVADOS")
            }
            Protocol.ACTION_SET_SERVO -> {
                val angle = Protocol.parseServoAngle(data)
                _uiState.value = currentState.copy(servoAngle = angle)
                logEvent("COMMAND", "Comando recibido: Servomotor SG90 a $angle°")
            }
            Protocol.ACTION_SET_ALERT_DIST -> {
                val dist = Protocol.parseAlertDistance(data)
                _uiState.value = currentState.copy(alertDistanceCm = dist)
                logEvent("COMMAND", "Comando recibido: Umbral crítico fijado a $dist cm")
            }
        }
    }

    /**
     * Monitorea cambios en la conexión.
     */
    private fun monitorConnectionState() {
        val manager = app.connectionManager ?: return
        viewModelScope.launch {
            manager.connectionState.collect { state ->
                _uiState.value = _uiState.value.copy(connectionState = state)
            }
        }
    }

    // ===================================================================
    // CONTROLES DE SIMULACIÓN LOCAL DE SENSORES
    // ===================================================================

    /** Modifica la distancia simulada del HC-SR04. */
    fun setSimulatedDistance(dist: Float) {
        _uiState.value = _uiState.value.copy(simulatedDistanceCm = dist)
    }

    /** Alterna la detección de movimiento simulada del PIR HC-SR501. */
    fun toggleSimulatedPir(detected: Boolean) {
        _uiState.value = _uiState.value.copy(simulatedPirDetected = detected)
        logEvent("SENSOR", if (detected) "PIR: Movimiento detectado" else "PIR: Área despejada")
    }

    /** Alterna el modo de oscilación automática de lecturas. */
    fun toggleAutoSimulation(active: Boolean) {
        _uiState.value = _uiState.value.copy(isAutoSimulatingSensors = active)
    }

    private fun logEvent(type: String, desc: String) {
        viewModelScope.launch {
            eventLogDao.insertEvent(
                EventLog(
                    eventType = type,
                    description = desc,
                    deviceRole = "NODO"
                )
            )
        }
    }

    fun disconnect() {
        app.connectionManager?.disconnect()
    }
}
