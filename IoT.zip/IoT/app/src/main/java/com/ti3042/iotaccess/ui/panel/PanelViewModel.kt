package com.ti3042.iotaccess.ui.panel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ti3042.iotaccess.IoTAccessApp
import com.ti3042.iotaccess.data.entity.EventLog
import com.ti3042.iotaccess.network.ConnectionManager
import com.ti3042.iotaccess.network.Protocol
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * ViewModel para el Panel de Control (Central de Monitoreo y Activador).
 *
 * Funciones principales:
 * 1. Escuchar la telemetría en tiempo real recibida por Wi-Fi TCP / Bluetooth (HC-SR04 y PIR).
 * 2. Enviar comandos interactivos al Nodo Perimetral cifrados con AES-256 (Armar/Desarmar,
 *    Buzzer, LEDs, Servomotor SG90 0°-180°, Distancia crítica).
 * 3. Registrar eventos en SQLite con Room para trazabilidad ISO 27001 / OT.
 */
class PanelViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as IoTAccessApp
    private val eventLogDao = app.database.eventLogDao()

    /** Flujo de historial de eventos en tiempo real desde SQLite. */
    val recentEvents: StateFlow<List<EventLog>> = eventLogDao.getRecentEvents(50)
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    /** Estado del Panel de Control. */
    data class PanelUiState(
        val connectionState: ConnectionManager.ConnectionState = ConnectionManager.ConnectionState.CONNECTED,
        val ultrasonicDistanceCm: Float = 0f,
        val pirMotionDetected: Boolean = false,
        val isSystemArmed: Boolean = false,
        val isBuzzerActive: Boolean = false,
        val isLedActive: Boolean = false,
        val servoAngle: Int = 0,
        val criticalDistanceCm: Float = 50f,
        val criticalDistanceInput: String = "50",
        val lastTelemetryTime: Long = 0L,
        val isIntrusionAlert: Boolean = false
    )

    private val _uiState = MutableStateFlow(PanelUiState())
    val uiState: StateFlow<PanelUiState> = _uiState.asStateFlow()

    init {
        listenIncomingMessages()
        monitorConnectionState()
    }

    /**
     * Escucha las tramas de telemetría y estado recibidas del Nodo Perimetral.
     */
    private fun listenIncomingMessages() {
        val manager = app.connectionManager ?: return
        viewModelScope.launch {
            manager.incomingMessages.collect { rawJson ->
                try {
                    val msg = Protocol.parseMessage(rawJson)
                    when (msg.type) {
                        Protocol.TYPE_TELEMETRY -> {
                            val telemetry = Protocol.parseTelemetry(msg.data)
                            val currentState = _uiState.value
                            val isCritical = telemetry.ultrasonicCm > 0 &&
                                    telemetry.ultrasonicCm < currentState.criticalDistanceCm
                            val intrusion = currentState.isSystemArmed && (telemetry.pirDetected || isCritical)

                            _uiState.value = currentState.copy(
                                ultrasonicDistanceCm = telemetry.ultrasonicCm,
                                pirMotionDetected = telemetry.pirDetected,
                                lastTelemetryTime = telemetry.timestamp,
                                isIntrusionAlert = intrusion
                            )

                            // Registrar evento en SQLite si se detecta intrusión o movimiento
                            if (intrusion) {
                                logEvent(
                                    type = "ALERT",
                                    desc = "¡Alerta de Intrusión! Distancia: ${telemetry.ultrasonicCm} cm, PIR: ${telemetry.pirDetected}"
                                )
                            }
                        }
                        Protocol.TYPE_STATUS -> {
                            val status = Protocol.parseStatus(msg.data)
                            _uiState.value = _uiState.value.copy(
                                isSystemArmed = status.armed,
                                isBuzzerActive = status.buzzerActive,
                                isLedActive = status.ledActive,
                                servoAngle = status.servoAngle,
                                criticalDistanceCm = status.alertDistanceCm,
                                criticalDistanceInput = status.alertDistanceCm.toInt().toString()
                            )
                        }
                    }
                } catch (e: Exception) {
                    logEvent("ERROR", "Error al procesar trama recibida: ${e.message}")
                }
            }
        }
    }

    /**
     * Monitorea cambios en el estado de la conexión.
     */
    private fun monitorConnectionState() {
        val manager = app.connectionManager ?: return
        viewModelScope.launch {
            manager.connectionState.collect { state ->
                _uiState.value = _uiState.value.copy(connectionState = state)
            }
        }
    }

    // ===================================================================
    // ACCIONES DE ACTIVADOR (Panel -> Nodo)
    // ===================================================================

    /** Alterna el estado de armado del sistema perimetral. */
    fun toggleArmed(armed: Boolean) {
        val action = if (armed) Protocol.ACTION_ARM else Protocol.ACTION_DISARM
        sendCommand(action)
        _uiState.value = _uiState.value.copy(isSystemArmed = armed)
        logEvent("COMMAND", if (armed) "Sistema Armado" else "Sistema Desarmado")
    }

    /** Activa o desactiva el Buzzer. */
    fun toggleBuzzer(active: Boolean) {
        val action = if (active) Protocol.ACTION_BUZZER_ON else Protocol.ACTION_BUZZER_OFF
        sendCommand(action)
        _uiState.value = _uiState.value.copy(isBuzzerActive = active)
        logEvent("COMMAND", if (active) "Buzzer Activado" else "Buzzer Desactivado")
    }

    /** Activa o desactiva los LEDs de alarma perimetral. */
    fun toggleLed(active: Boolean) {
        val action = if (active) Protocol.ACTION_LED_ON else Protocol.ACTION_LED_OFF
        sendCommand(action)
        _uiState.value = _uiState.value.copy(isLedActive = active)
        logEvent("COMMAND", if (active) "LEDs Activados" else "LEDs Desactivados")
    }

    /** Ajusta el ángulo del Servomotor SG90 (pestillo de acceso de 0° a 180°). */
    fun setServoAngle(angle: Int) {
        val clampedAngle = angle.coerceIn(0, 180)
        _uiState.value = _uiState.value.copy(servoAngle = clampedAngle)
        val jsonMsg = Protocol.createServoCommand(clampedAngle)
        sendRawMessage(jsonMsg)
        logEvent("COMMAND", "Pestillo Servomotor SG90 fijado a $clampedAngle°")
    }

    /** Actualiza el campo de texto de la distancia crítica de alerta. */
    fun updateCriticalDistanceInput(input: String) {
        _uiState.value = _uiState.value.copy(criticalDistanceInput = input)
    }

    /** Aplica la distancia crítica de alerta y la envía al Nodo. */
    fun applyCriticalDistance() {
        val dist = _uiState.value.criticalDistanceInput.toFloatOrNull() ?: return
        if (dist > 0) {
            _uiState.value = _uiState.value.copy(criticalDistanceCm = dist)
            val jsonMsg = Protocol.createAlertDistanceCommand(dist)
            sendRawMessage(jsonMsg)
            logEvent("COMMAND", "Distancia crítica de alerta configurada a $dist cm")
        }
    }

    /** Envía un comando simple por la red. */
    private fun sendCommand(action: String) {
        val msg = Protocol.createCommand(action)
        sendRawMessage(msg)
    }

    /** Envía el mensaje mediante el ConnectionManager cifrado en AES-256. */
    private fun sendRawMessage(msg: String) {
        viewModelScope.launch {
            app.connectionManager?.sendMessage(msg)
        }
    }

    /** Registra un evento en la base de datos SQLite para auditoría ISO 27001. */
    private fun logEvent(type: String, desc: String) {
        viewModelScope.launch {
            eventLogDao.insertEvent(
                EventLog(
                    eventType = type,
                    description = desc,
                    deviceRole = "PANEL"
                )
            )
        }
    }

    /** Desconecta la sesión y libera recursos. */
    fun disconnect() {
        app.connectionManager?.disconnect()
    }
}
