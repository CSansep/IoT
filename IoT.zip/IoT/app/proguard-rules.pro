# Reglas de ProGuard para el módulo :app
# No se requieren reglas adicionales para debug
-keepattributes *Annotation*

