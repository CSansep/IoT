// ============================================================
// Configuración de repositorios y módulos del proyecto
// TI3042 - Sistema de Control de Accesos y Monitoreo Perimetral
// ============================================================

pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "IoTAccess"
include(":app")

